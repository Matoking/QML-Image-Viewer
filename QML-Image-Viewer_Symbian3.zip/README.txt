QML Image Viewer v. 0.9
by Matoking

e-mail: jannepulk@gmail.com
project github page: https://github.com/Matoking/QML-Image-Viewer
twitter: @Matoking

--

A simple QML image viewer designed for Symbian touch-screen phones.

The source code and other included assets are public domain.

--

Instructions

--

Tapping the middle screen when viewing pictures brings up the icons which should be self-explainatory to use.

You can also double-tap the screen to revert zoom to 100% and to fit the image to screen.

Volume keys can also be used to zoom the image.

--

If you like this software feel free to donate Bitcoins to :
1M8Xa6crWwrymzUayCML1MJGqjF4JdGHHx